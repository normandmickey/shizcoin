Sample configuration files for:
```
SystemD: shizcoind.service
Upstart: shizcoind.conf
OpenRC:  shizcoind.openrc
         shizcoind.openrcconf
CentOS:  shizcoind.init
macOS:    org.shizcoin.shizcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
